﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ObejectInitializer
{
    public class StudentName
    {
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public int ID { get; set; }

        public StudentName()
        {

        }
        public StudentName(string firstName, string lastName)
        {
            FirstName = firstName;
            LastName = lastName;
        }

        public override string ToString() => FirstName +" "+ LastName+" " + ID;
    }
}
