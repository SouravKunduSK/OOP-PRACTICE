﻿using System;

namespace ObejectInitializer
{
     class Program
    {
         static void Main(string[] args)
        {
            StudentName student1 = new StudentName ("Sourav", "Kundu" );
            StudentName student2 = new StudentName { FirstName = "Sourav", LastName = "Kundu" };
            StudentName student3 = new StudentName { ID = 180144 };
            StudentName student4 = new StudentName { FirstName = "Sourav", LastName = "Kundu", ID = 180144 };
            StudentName student5 = new StudentName { FirstName = "Sourav", LastName = "Kundu", ID = 180144 };

            Console.WriteLine(student1.ToString());
            Console.WriteLine(student2.ToString());
            Console.WriteLine(student3.ToString());
            Console.WriteLine(student4.ToString());
            Console.WriteLine(student5.ToString());
        }
    }
}
